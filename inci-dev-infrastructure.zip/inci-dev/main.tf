terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

# ─── VPC & Réseau ────────────────────────────────────────────────
module "vpc" {
  source       = "./modules/vpc"
  project_name = var.project_name
  vpc_cidr     = var.vpc_cidr
  azs          = var.availability_zones
}

# ─── Sécurité (Security Groups) ──────────────────────────────────
module "security" {
  source       = "./modules/security"
  project_name = var.project_name
  vpc_id       = module.vpc.vpc_id
  vpc_cidr     = var.vpc_cidr
  allowed_ssh_cidrs = var.allowed_ssh_cidrs
}

# ─── Bastion (sous-réseau public) ────────────────────────────────
module "bastion" {
  source            = "./modules/bastion"
  project_name      = var.project_name
  subnet_id         = module.vpc.public_subnet_ids[0]
  security_group_id = module.security.bastion_sg_id
  key_name          = var.key_pair_name
  instance_type     = var.bastion_instance_type
}

# ─── Applications Linux (Gitea, Wiki.js, Excalidraw) ─────────────
module "apps" {
  source            = "./modules/apps"
  project_name      = var.project_name
  subnet_id         = module.vpc.private_subnet_ids[0]
  security_group_id = module.security.apps_sg_id
  key_name          = var.key_pair_name
  instance_type     = var.apps_instance_type
}

# ─── Instances Windows (une par collaborateur) ───────────────────
module "windows" {
  source            = "./modules/windows"
  project_name      = var.project_name
  subnet_ids        = module.vpc.private_subnet_ids
  security_group_id = module.security.windows_sg_id
  key_name          = var.key_pair_name
  instance_type     = var.windows_instance_type
  collaborators     = var.collaborators
}

# ─── DNS Privé Route 53 (Bonus) ──────────────────────────────────
module "dns" {
  source       = "./modules/dns"
  project_name = var.project_name
  vpc_id       = module.vpc.vpc_id
  domain_name  = var.domain_name
  apps_private_ip = module.apps.private_ip
}

# ─── Alarmes CloudWatch ──────────────────────────────────────────
module "cloudwatch" {
  source              = "./modules/security"
  create_alarms       = true
  project_name        = var.project_name
  bastion_instance_id = module.bastion.instance_id
  apps_instance_id    = module.apps.instance_id
  windows_instance_ids = module.windows.instance_ids
  sns_email           = var.alert_email

  # passthrough requis
  vpc_id            = module.vpc.vpc_id
  vpc_cidr          = var.vpc_cidr
  allowed_ssh_cidrs = var.allowed_ssh_cidrs
}
