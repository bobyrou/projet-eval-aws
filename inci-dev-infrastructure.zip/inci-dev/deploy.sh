#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────
#  deploy.sh — Déploiement complet de l'infrastructure Inci Dev
#  Usage : ./deploy.sh [--destroy]
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

log()  { echo -e "${GREEN}[INFO]${NC}  $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC}  $*"; }
err()  { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

# ── Vérifications préalables ─────────────────────────────────────
command -v terraform >/dev/null 2>&1 || err "terraform n'est pas installé."
command -v aws       >/dev/null 2>&1 || err "aws CLI n'est pas installé."

aws sts get-caller-identity >/dev/null 2>&1 || err "Credentials AWS non configurés. Lancez 'aws configure'."

[ -f terraform.tfvars ] || err "Fichier terraform.tfvars absent. Copiez terraform.tfvars.example et adaptez-le."

# ── Destruction ──────────────────────────────────────────────────
if [[ "${1:-}" == "--destroy" ]]; then
  warn "Destruction de TOUTE l'infrastructure dans 10 secondes..."
  warn "Appuyez sur Ctrl+C pour annuler."
  sleep 10
  terraform destroy -auto-approve
  log "Infrastructure détruite avec succès."
  exit 0
fi

# ── Déploiement ──────────────────────────────────────────────────
log "Initialisation de Terraform..."
terraform init -upgrade

log "Validation de la configuration..."
terraform validate

log "Planification des changements..."
terraform plan -out=tfplan

log "Application de l'infrastructure..."
terraform apply tfplan

log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
log "  Déploiement terminé !"
log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
terraform output
