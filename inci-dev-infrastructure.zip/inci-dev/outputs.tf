output "bastion_public_ip" {
  description = "IP publique du bastion — point d'entrée unique"
  value       = module.bastion.public_ip
}

output "apps_private_ip" {
  description = "IP privée du serveur d'applications"
  value       = module.apps.private_ip
}

output "windows_private_ips" {
  description = "IPs privées des instances Windows (indexées par collaborateur)"
  value       = module.windows.instance_private_ips
}

output "gitea_url" {
  description = "URL interne Gitea"
  value       = "http://gitea.${var.domain_name}"
}

output "wikijs_url" {
  description = "URL interne Wiki.js"
  value       = "http://wikijs.${var.domain_name}"
}

output "excalidraw_url" {
  description = "URL interne Excalidraw"
  value       = "http://draw.${var.domain_name}"
}

output "ssh_bastion_command" {
  description = "Commande SSH pour se connecter au bastion"
  value       = "ssh -i ~/.ssh/${var.key_pair_name}.pem ec2-user@${module.bastion.public_ip}"
}
