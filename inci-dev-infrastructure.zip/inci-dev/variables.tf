variable "aws_region" {
  description = "Région AWS cible"
  type        = string
  default     = "eu-west-3" # Paris
}

variable "project_name" {
  description = "Préfixe utilisé pour nommer toutes les ressources"
  type        = string
  default     = "inci-dev"
}

variable "vpc_cidr" {
  description = "Bloc CIDR du VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "availability_zones" {
  description = "Zones de disponibilité à utiliser"
  type        = list(string)
  default     = ["eu-west-3a", "eu-west-3b"]
}

variable "domain_name" {
  description = "Nom de domaine interne (zone privée Route 53)"
  type        = string
  default     = "inci.dev"
}

variable "key_pair_name" {
  description = "Nom de la paire de clés EC2 AWS (doit exister dans la région)"
  type        = string
}

variable "allowed_ssh_cidrs" {
  description = "CIDRs autorisés à se connecter au bastion en SSH"
  type        = list(string)
  default     = ["0.0.0.0/0"] # À restreindre en production
}

variable "bastion_instance_type" {
  description = "Type d'instance pour le bastion"
  type        = string
  default     = "t3.micro"
}

variable "apps_instance_type" {
  description = "Type d'instance pour le serveur d'applications"
  type        = string
  default     = "t3.medium"
}

variable "windows_instance_type" {
  description = "Type d'instance pour les machines Windows"
  type        = string
  default     = "t3.medium"
}

variable "collaborators" {
  description = "Liste des collaborateurs — chacun obtient une instance Windows dédiée"
  type = list(object({
    name  = string
    email = string
  }))
  default = [
    { name = "alice", email = "alice@inci.dev" },
    { name = "bob",   email = "bob@inci.dev"   }
  ]
}

variable "alert_email" {
  description = "Adresse e-mail pour les alertes CloudWatch / SNS"
  type        = string
  default     = "admin@inci.dev"
}
