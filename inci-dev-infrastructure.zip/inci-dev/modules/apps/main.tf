variable "project_name"      {}
variable "subnet_id"         {}
variable "security_group_id" {}
variable "key_name"          {}
variable "instance_type"     { default = "t3.medium" }

data "aws_ami" "ubuntu" {
  most_recent = true
  owners      = ["099720109477"] # Canonical
  filter {
    name   = "name"
    values = ["ubuntu/images/hvm-ssd/ubuntu-jammy-22.04-amd64-server-*"]
  }
  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

resource "aws_instance" "apps" {
  ami                    = data.aws_ami.ubuntu.id
  instance_type          = var.instance_type
  subnet_id              = var.subnet_id
  vpc_security_group_ids = [var.security_group_id]
  key_name               = var.key_name

  root_block_device {
    volume_size = 30
    volume_type = "gp3"
    encrypted   = true
  }

  user_data = <<-EOF
    #!/bin/bash
    set -e
    apt-get update -y
    apt-get install -y docker.io docker-compose-v2 nginx

    systemctl enable docker
    systemctl start docker

    mkdir -p /opt/inci-dev
    cat > /opt/inci-dev/docker-compose.yml <<'COMPOSE'
    version: "3.9"

    networks:
      intranet:
        driver: bridge

    volumes:
      gitea_data:
      wikijs_data:
      wikijs_db:

    services:
      # ── Gitea ─────────────────────────────────────────────────
      gitea:
        image: gitea/gitea:latest
        container_name: gitea
        restart: unless-stopped
        environment:
          - USER_UID=1000
          - USER_GID=1000
          - GITEA__server__DOMAIN=gitea.inci.dev
          - GITEA__server__HTTP_PORT=3000
        volumes:
          - gitea_data:/data
        ports:
          - "3000:3000"
        networks:
          - intranet

      # ── Wiki.js ───────────────────────────────────────────────
      wikijs_db:
        image: postgres:15-alpine
        container_name: wikijs_db
        restart: unless-stopped
        environment:
          POSTGRES_DB: wikijs
          POSTGRES_USER: wikijs
          POSTGRES_PASSWORD: wikijs_secure_pass
        volumes:
          - wikijs_db:/var/lib/postgresql/data
        networks:
          - intranet

      wikijs:
        image: requarks/wiki:2
        container_name: wikijs
        restart: unless-stopped
        depends_on:
          - wikijs_db
        environment:
          DB_TYPE: postgres
          DB_HOST: wikijs_db
          DB_PORT: 5432
          DB_NAME: wikijs
          DB_USER: wikijs
          DB_PASS: wikijs_secure_pass
        ports:
          - "3001:3000"
        networks:
          - intranet

      # ── Excalidraw ────────────────────────────────────────────
      excalidraw:
        image: excalidraw/excalidraw:latest
        container_name: excalidraw
        restart: unless-stopped
        ports:
          - "3002:80"
        networks:
          - intranet
    COMPOSE

    # Démarrer tous les services
    cd /opt/inci-dev
    docker compose up -d

    # ── Nginx reverse proxy ───────────────────────────────────────
    cat > /etc/nginx/sites-available/inci-dev <<'NGINX'
    server {
        listen 80;
        server_name gitea.inci.dev;
        location / {
            proxy_pass http://localhost:3000;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }
    }

    server {
        listen 80;
        server_name wikijs.inci.dev;
        location / {
            proxy_pass http://localhost:3001;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }
    }

    server {
        listen 80;
        server_name draw.inci.dev;
        location / {
            proxy_pass http://localhost:3002;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }
    }
    NGINX

    ln -sf /etc/nginx/sites-available/inci-dev /etc/nginx/sites-enabled/inci-dev
    rm -f /etc/nginx/sites-enabled/default
    nginx -t && systemctl restart nginx
  EOF

  metadata_options {
    http_tokens   = "required"
    http_endpoint = "enabled"
  }

  tags = { Name = "${var.project_name}-apps" }
}

output "instance_id" { value = aws_instance.apps.id }
output "private_ip"  { value = aws_instance.apps.private_ip }
