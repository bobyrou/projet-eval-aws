variable "project_name"   {}
variable "vpc_id"         {}
variable "domain_name"    { default = "inci.dev" }
variable "apps_private_ip" {}

# Zone DNS privée (accessible uniquement depuis le VPC)
resource "aws_route53_zone" "private" {
  name = var.domain_name

  vpc {
    vpc_id = var.vpc_id
  }

  tags = { Name = "${var.project_name}-dns-zone" }
}

# ── Enregistrements A ────────────────────────────────────────────

resource "aws_route53_record" "gitea" {
  zone_id = aws_route53_zone.private.zone_id
  name    = "gitea.${var.domain_name}"
  type    = "A"
  ttl     = 300
  records = [var.apps_private_ip]
}

resource "aws_route53_record" "wikijs" {
  zone_id = aws_route53_zone.private.zone_id
  name    = "wikijs.${var.domain_name}"
  type    = "A"
  ttl     = 300
  records = [var.apps_private_ip]
}

resource "aws_route53_record" "excalidraw" {
  zone_id = aws_route53_zone.private.zone_id
  name    = "draw.${var.domain_name}"
  type    = "A"
  ttl     = 300
  records = [var.apps_private_ip]
}

output "zone_id" { value = aws_route53_zone.private.zone_id }
