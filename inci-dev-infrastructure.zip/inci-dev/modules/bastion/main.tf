variable "project_name"      {}
variable "subnet_id"         {}
variable "security_group_id" {}
variable "key_name"          {}
variable "instance_type"     { default = "t3.micro" }

data "aws_ami" "amazon_linux" {
  most_recent = true
  owners      = ["amazon"]
  filter {
    name   = "name"
    values = ["al2023-ami-*-x86_64"]
  }
  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

resource "aws_instance" "bastion" {
  ami                    = data.aws_ami.amazon_linux.id
  instance_type          = var.instance_type
  subnet_id              = var.subnet_id
  vpc_security_group_ids = [var.security_group_id]
  key_name               = var.key_name
  associate_public_ip_address = true

  # Hardening bastion : désactiver les services inutiles, activer fail2ban
  user_data = <<-EOF
    #!/bin/bash
    set -e
    dnf update -y
    dnf install -y fail2ban

    # Activer fail2ban pour protéger SSH
    systemctl enable fail2ban
    systemctl start fail2ban

    cat > /etc/fail2ban/jail.local <<'JAIL'
    [sshd]
    enabled  = true
    port     = ssh
    maxretry = 5
    bantime  = 3600
    JAIL

    systemctl restart fail2ban

    # Agent SSH forwarding activé par défaut
    echo "AllowAgentForwarding yes" >> /etc/ssh/sshd_config
    systemctl restart sshd
  EOF

  metadata_options {
    http_tokens   = "required"  # IMDSv2 obligatoire
    http_endpoint = "enabled"
  }

  tags = { Name = "${var.project_name}-bastion" }
}

resource "aws_eip" "bastion" {
  instance = aws_instance.bastion.id
  domain   = "vpc"
  tags     = { Name = "${var.project_name}-bastion-eip" }
}

output "instance_id" { value = aws_instance.bastion.id }
output "public_ip"   { value = aws_eip.bastion.public_ip }
