variable "project_name"      {}
variable "subnet_ids"        { type = list(string) }
variable "security_group_id" {}
variable "key_name"          {}
variable "instance_type"     { default = "t3.medium" }
variable "collaborators" {
  type = list(object({
    name  = string
    email = string
  }))
}

data "aws_ami" "windows" {
  most_recent = true
  owners      = ["amazon"]
  filter {
    name   = "name"
    values = ["Windows_Server-2022-English-Full-Base-*"]
  }
  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

resource "aws_instance" "windows" {
  count         = length(var.collaborators)
  ami           = data.aws_ami.windows.id
  instance_type = var.instance_type
  # Distribuer les instances sur les sous-réseaux disponibles
  subnet_id              = var.subnet_ids[count.index % length(var.subnet_ids)]
  vpc_security_group_ids = [var.security_group_id]
  key_name               = var.key_name

  root_block_device {
    volume_size = 50
    volume_type = "gp3"
    encrypted   = true
  }

  # Activer WinRM + VS Code Remote SSH
  user_data = <<-EOF
    <powershell>
    # Activer WinRM (gestion à distance)
    Enable-PSRemoting -Force
    Set-Item WSMan:\localhost\Service\Auth\Basic -Value $true
    Set-Item WSMan:\localhost\Service\AllowUnencrypted -Value $false

    # Installer OpenSSH Server (nécessaire pour VS Code Remote)
    Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0
    Start-Service sshd
    Set-Service -Name sshd -StartupType 'Automatic'

    # Firewall : n'autoriser SSH que depuis le VPC
    New-NetFirewallRule -Name "AllowSSH" -DisplayName "Allow SSH from VPC" `
      -Direction Inbound -LocalPort 22 -Protocol TCP -Action Allow

    # Nommer la machine selon le collaborateur
    Rename-Computer -NewName "WIN-${upper(var.collaborators[count.index].name)}" -Force

    # Installer Chocolatey (gestionnaire de paquets)
    Set-ExecutionPolicy Bypass -Scope Process -Force
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
    iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))

    # Installer les outils développeur courants
    choco install -y git vscode googlechrome

    Restart-Computer -Force
    </powershell>
  EOF

  metadata_options {
    http_tokens   = "required"
    http_endpoint = "enabled"
  }

  tags = {
    Name         = "${var.project_name}-windows-${var.collaborators[count.index].name}"
    Collaborator = var.collaborators[count.index].name
    Email        = var.collaborators[count.index].email
  }
}

output "instance_ids"        { value = aws_instance.windows[*].id }
output "instance_private_ips" {
  value = {
    for i, collab in var.collaborators :
    collab.name => aws_instance.windows[i].private_ip
  }
}
