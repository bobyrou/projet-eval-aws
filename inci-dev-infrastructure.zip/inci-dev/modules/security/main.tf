variable "project_name"       {}
variable "vpc_id"             {}
variable "vpc_cidr"           {}
variable "allowed_ssh_cidrs"  { type = list(string) }
variable "create_alarms"      { type = bool; default = false }
variable "bastion_instance_id" { default = "" }
variable "apps_instance_id"   { default = "" }
variable "windows_instance_ids" { type = list(string); default = [] }
variable "sns_email"          { default = "" }

# ════════════════════════════════════════════════════════════════
#  SECURITY GROUPS
# ════════════════════════════════════════════════════════════════

# ─── SG Bastion ──────────────────────────────────────────────────
resource "aws_security_group" "bastion" {
  name        = "${var.project_name}-sg-bastion"
  description = "Accès SSH public vers le bastion"
  vpc_id      = var.vpc_id

  ingress {
    description = "SSH depuis IPs autorisées"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = var.allowed_ssh_cidrs
  }

  egress {
    description = "Tout le trafic sortant autorisé"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${var.project_name}-sg-bastion" }
}

# ─── SG Instances Windows ────────────────────────────────────────
resource "aws_security_group" "windows" {
  name        = "${var.project_name}-sg-windows"
  description = "Accès RDP uniquement depuis le bastion"
  vpc_id      = var.vpc_id

  ingress {
    description     = "RDP depuis le bastion"
    from_port       = 3389
    to_port         = 3389
    protocol        = "tcp"
    security_groups = [aws_security_group.bastion.id]
  }

  ingress {
    description     = "SSH/WinRM depuis le bastion (gestion)"
    from_port       = 5986
    to_port         = 5986
    protocol        = "tcp"
    security_groups = [aws_security_group.bastion.id]
  }

  egress {
    description = "Accès aux applications internes"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
  }

  egress {
    description = "Accès HTTPS sortant (mises à jour)"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    description = "DNS interne"
    from_port   = 53
    to_port     = 53
    protocol    = "udp"
    cidr_blocks = [var.vpc_cidr]
  }

  tags = { Name = "${var.project_name}-sg-windows" }
}

# ─── SG Serveur d'applications ───────────────────────────────────
resource "aws_security_group" "apps" {
  name        = "${var.project_name}-sg-apps"
  description = "Applications accessibles depuis le VPC uniquement"
  vpc_id      = var.vpc_id

  ingress {
    description = "Gitea HTTP depuis le VPC"
    from_port   = 3000
    to_port     = 3000
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
  }

  ingress {
    description = "Wiki.js HTTP depuis le VPC"
    from_port   = 3001
    to_port     = 3001
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
  }

  ingress {
    description = "Excalidraw HTTP depuis le VPC"
    from_port   = 3002
    to_port     = 3002
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
  }

  ingress {
    description     = "SSH depuis le bastion (déploiement)"
    from_port       = 22
    to_port         = 22
    protocol        = "tcp"
    security_groups = [aws_security_group.bastion.id]
  }

  # Nginx reverse-proxy écoute sur 80
  ingress {
    description = "HTTP Nginx depuis le VPC"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
  }

  egress {
    description = "Sortie Internet (pull images Docker)"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${var.project_name}-sg-apps" }
}

# ════════════════════════════════════════════════════════════════
#  CLOUDWATCH ALARMES (créées uniquement si create_alarms = true)
# ════════════════════════════════════════════════════════════════

resource "aws_sns_topic" "alerts" {
  count = var.create_alarms ? 1 : 0
  name  = "${var.project_name}-security-alerts"
  tags  = { Name = "${var.project_name}-sns-alerts" }
}

resource "aws_sns_topic_subscription" "email" {
  count     = var.create_alarms && var.sns_email != "" ? 1 : 0
  topic_arn = aws_sns_topic.alerts[0].arn
  protocol  = "email"
  endpoint  = var.sns_email
}

# Alarme : CPU élevé sur le bastion (potentielle attaque brute-force)
resource "aws_cloudwatch_metric_alarm" "bastion_cpu" {
  count               = var.create_alarms && var.bastion_instance_id != "" ? 1 : 0
  alarm_name          = "${var.project_name}-bastion-high-cpu"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "CPUUtilization"
  namespace           = "AWS/EC2"
  period              = 120
  statistic           = "Average"
  threshold           = 80
  alarm_description   = "CPU bastion > 80% — possible attaque brute-force SSH"
  alarm_actions       = [aws_sns_topic.alerts[0].arn]
  dimensions          = { InstanceId = var.bastion_instance_id }
  tags                = { Name = "${var.project_name}-alarm-bastion-cpu" }
}

# Alarme : Connexions réseau anormales sur le bastion
resource "aws_cloudwatch_metric_alarm" "bastion_network_in" {
  count               = var.create_alarms && var.bastion_instance_id != "" ? 1 : 0
  alarm_name          = "${var.project_name}-bastion-network-spike"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "NetworkPacketsIn"
  namespace           = "AWS/EC2"
  period              = 60
  statistic           = "Sum"
  threshold           = 100000
  alarm_description   = "Pic réseau sur le bastion — possible scan de ports"
  alarm_actions       = [aws_sns_topic.alerts[0].arn]
  dimensions          = { InstanceId = var.bastion_instance_id }
  tags                = { Name = "${var.project_name}-alarm-bastion-network" }
}

# Alarme : CPU élevé sur le serveur d'applications
resource "aws_cloudwatch_metric_alarm" "apps_cpu" {
  count               = var.create_alarms && var.apps_instance_id != "" ? 1 : 0
  alarm_name          = "${var.project_name}-apps-high-cpu"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 3
  metric_name         = "CPUUtilization"
  namespace           = "AWS/EC2"
  period              = 300
  statistic           = "Average"
  threshold           = 90
  alarm_description   = "CPU apps > 90% — possible attaque DoS ou cryptominer"
  alarm_actions       = [aws_sns_topic.alerts[0].arn]
  dimensions          = { InstanceId = var.apps_instance_id }
  tags                = { Name = "${var.project_name}-alarm-apps-cpu" }
}

# Alarmes CPU élevé sur les instances Windows (par collaborateur)
resource "aws_cloudwatch_metric_alarm" "windows_cpu" {
  count               = var.create_alarms ? length(var.windows_instance_ids) : 0
  alarm_name          = "${var.project_name}-windows-${count.index + 1}-high-cpu"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 3
  metric_name         = "CPUUtilization"
  namespace           = "AWS/EC2"
  period              = 300
  statistic           = "Average"
  threshold           = 95
  alarm_description   = "CPU machine Windows ${count.index + 1} > 95%"
  alarm_actions       = [aws_sns_topic.alerts[0].arn]
  dimensions          = { InstanceId = var.windows_instance_ids[count.index] }
  tags                = { Name = "${var.project_name}-alarm-windows-${count.index + 1}-cpu" }
}

# ─── Outputs ─────────────────────────────────────────────────────
output "bastion_sg_id" { value = aws_security_group.bastion.id }
output "windows_sg_id" { value = aws_security_group.windows.id }
output "apps_sg_id"    { value = aws_security_group.apps.id }
